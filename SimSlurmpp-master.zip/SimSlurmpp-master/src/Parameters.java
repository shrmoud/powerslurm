public class Parameters 
{
	public int pid;
	public int tid;
}
