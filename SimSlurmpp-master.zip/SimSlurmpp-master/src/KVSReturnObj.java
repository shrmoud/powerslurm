import java.io.Serializable;

public class KVSReturnObj implements Serializable 
{
	Object key;
	Object value;
	String identifier;
	String type;
	String forWhat;
	boolean result;
}
